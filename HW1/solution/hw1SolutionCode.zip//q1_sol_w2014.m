%%% test function generates all outputs that we need for the various answers of Q2
function q1_sol_w2014
% 
M=1;
lambda = 0; %1e-3;
[w_newton err_train_newton err_test_newton] = least_squares_poly_Newton(M, lambda);
w_newton
[w_sgrad err_train_sgrad err_test_sgrad] = least_squares_poly_sgrad(M, lambda);
w_sgrad
[w_grad err_train_grad err_test_grad] = least_squares_poly_grad(M, lambda);
w_grad

%% (b)
clear; close all;
lambda = 0;
err_train_history = [];
err_test_history = [];
M_list = 0:9;
for M = M_list
    [w err_train err_test] = least_squares_poly_Newton(M, lambda);
    err_train_history = [err_train_history, err_train];
    err_test_history = [err_test_history, err_test];
end

figure, plot(1:length(M_list), err_train_history, 'blue', 1:length(M_list), err_test_history, 'r');
title('2(b) fix lambda=0, vary M');
legend('train','test');
xlabel('M');
ylabel('E_{RMS}');


%% (c)
clear; close all;
M = 9;
err_train_history = [];
err_test_history = [];
lambda_list = [0, 10.^[-8:1:0]];
for lambda = lambda_list
    [w err_train err_test] = least_squares_poly_Newton(M, lambda);
    err_train_history = [err_train_history, err_train];
    err_test_history = [err_test_history, err_test];
end

nlambda = length(lambda_list);
figure, plot(1:nlambda, err_train_history, 'blue', 1:nlambda, err_test_history, 'r');
title('2(c) fix M=9, vary lambda');
legend('train','test');
xlabel('\lambda');
ylabel('E_{RMS}')






%%%Stochastic Gradient Descent method (given current value of M and lambda)
function [w err_train err_test] = least_squares_poly_sgrad(M, lambda)

load data/q1xTrain.dat
load data/q1yTrain.dat

load data/q1xTest.dat
load data/q1yTest.dat

% M=9;
xtrain = q1xTrain;
xtest = q1xTest;

Xtrain = generate_polynomial_features(q1xTrain, M);
Xtest = generate_polynomial_features(q1xTest, M);

ytrain = q1yTrain;
ytest = q1yTest;

w_LS = (Xtrain'*Xtrain + lambda*eye(M))\(Xtrain'*ytrain);

w = zeros(M+1,1);
N = length(ytrain);
eta = 1e-4;
tmax = 100000;
train_err_list = zeros(1,tmax);
for t=1:tmax
    for i=1:N
        phi = Xtrain(i,:)';
        ypred = w'*phi;
        g = - (ytrain(i) - ypred)*phi + lambda*w/N;
        w = w - eta*g;
    end
    
    train_err =  mean((ytrain-Xtrain*w).^2)/length(ytrain);
    train_err_list(t) = train_err;
    
    if mod(t,floor(tmax/10))==0
        figure(2), plot(1:t, train_err_list(1:t))
    end
end
figure(2), plot(train_err_list)

ypred_train = Xtrain*w;
ypred_test = Xtest*w;

err_train = sqrt(mean((ytrain-ypred_train).^2));
err_test = sqrt(mean((ytest-ypred_test).^2));


err_train_LS = sqrt(mean((ytrain-Xtrain*w_LS).^2)/length(ytrain));
err_test_LS = sqrt(mean((ytest-Xtest*w_LS).^2)/length(ytest));

% figure(1),
subplot(2,2,1),  plot(xtrain, ytrain,'.'), title('training data')
subplot(2,2,2),  plot(xtrain, ypred_train,'.'), title('learned prediction training data')

subplot(2,2,3),  plot(xtest, ytest,'.'), title('test data')
subplot(2,2,4),  plot(xtest, ypred_test,'.'), title('learned prediction test data')

% err_train
% err_test

fprintf('M=%g, lambda=%g, err_train=%g, err_test=%g\n', M, lambda, err_train, err_test);

% err_train_LS
% err_test_LS

return

%%%Gradient Descent method (given current value of M and lambda)
function [w err_train err_test] = least_squares_poly_grad(M, lambda)

load data/q1xTrain.dat
load data/q1yTrain.dat

load data/q1xTest.dat
load data/q1yTest.dat

% M=9;
xtrain = q1xTrain;
xtest = q1xTest;
Xtrain = generate_polynomial_features(q1xTrain, M);
Xtest = generate_polynomial_features(q1xTest, M);

ytrain = q1yTrain;
ytest = q1yTest;

w_LS = (Xtrain'*Xtrain + lambda*eye(M))\(Xtrain'*ytrain);

w = zeros(M+1,1);
N = length(ytrain);
eta = 1e-3;
tmax = 300000;
train_err_list = zeros(1,tmax);
for t = 1:tmax,
    g_exact = (-Xtrain'*(ytrain-Xtrain*w) +lambda*w)/N;
    g = g_exact;
    
    w = w - eta*g;
    
    train_err =  mean((ytrain-Xtrain*w).^2);
    train_err_list(t) = train_err;
    
    if mod(t,floor(tmax/10))==0
        figure(2), plot(1:t, train_err_list(1:t))
    end
end
figure(2), plot(train_err_list)

ypred_train = Xtrain*w;
ypred_test = Xtest*w;

err_train = sqrt(mean((ytrain-ypred_train).^2));
err_test = sqrt(mean((ytest-ypred_test).^2));

% figure(1),
subplot(2,2,1),  plot(xtrain, ytrain,'.'), title('training data')
subplot(2,2,2),  plot(xtrain, ypred_train,'.'), title('learned prediction training data')

subplot(2,2,3),  plot(xtest, ytest,'.'), title('test data')
subplot(2,2,4),  plot(xtest, ypred_test,'.'), title('learned prediction test data')

% err_train
% err_test

fprintf('M=%g, lambda=%g, err_train=%g, err_test=%g\n', M, lambda, err_train, err_test);

% err_train_LS
% err_test_LS

return


%%%Generates least squares using Newton's Methoud
function [w err_train err_test] = least_squares_poly_Newton(M, lambda)

load data/q1xTrain.dat
load data/q1yTrain.dat
load data/q1xTest.dat
load data/q1yTest.dat

xtrain = q1xTrain;
xtest = q1xTest;

Xtrain = generate_polynomial_features(q1xTrain, M);
Xtest = generate_polynomial_features(q1xTest, M);

ytrain = q1yTrain;
ytest = q1yTest;

%%  For least squares, one Newton step is enough to get exact solution.
%%  This is because LS is quadratic in terms of w,
%%  so the quadratic approximation (main assumption for Newton's method)
%%  for least squares is exact and so converges in one step.
%%

w_LS = (Xtrain'*Xtrain + lambda*eye(M+1))\(Xtrain'*ytrain);
w = w_LS;

ypred_train = Xtrain*w_LS;
ypred_test = Xtest*w_LS;

err_train = sqrt(mean((ytrain-ypred_train).^2));
err_test = sqrt(mean((ytest-ypred_test).^2));

figure(1),
subplot(2,2,1),  plot(xtrain, ytrain,'.'), title('training data')
subplot(2,2,2),  plot(xtrain, ypred_train,'.'), title('learned prediction training data')

subplot(2,2,3),  plot(xtest, ytest,'.'), title('test data')
subplot(2,2,4),  plot(xtest, ypred_test,'.'), title('learned prediction test data')


fprintf('M=%g, lambda=%g, err_train=%g, err_test=%g\n', M, lambda, err_train, err_test);

return

%%%Generates the design matrix Phi
function Phi = generate_polynomial_features(x, M)
% x needs to be a column vector

x = x(:);
N = length(x);

% figure(1), plot(x,y, '.');
% M = 5;
Phi = ones(N,1);
for m=1:M,
    Phi = [Phi, x.^m];
end

return
