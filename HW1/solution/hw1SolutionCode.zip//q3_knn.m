% Gives the indices of the K closets neighbors
function [idx, class] =  q3_knn(train_mat, train_labels, test_mat, idx, k)
  d = zeros(1000, 1);
  
  % Create Gaussian Mask:
  G = [1 2 5 5 2 1];
  G = G' * G;
  G = G / sum(G(:));

  % COMMENT NEXT LINE to enable gaussian smoothing
  G = [1];     
  test_ex = reshape(test_mat(idx, :, :), 28, 28);
  test_ex = conv2(test_ex, G, 'valid');
  for i=1:1000
    training_ex = reshape(train_mat(i, :, :), 28, 28);
    training_ex = conv2(training_ex, G, 'valid');
    dis = test_ex - training_ex;
    dis = dis .* dis;
    d(i) = sum(dis(:));
  end

  [s, id] = sort(d);
  idx = id(1:k);
  sums = zeros(10, 1);
  for j=1:k
    label = train_labels(idx(j)) + 1;
    sums(label) = sums(label) + 1;
  end
  
  [count, class] = max(sums);
  class = class - 1;
end

