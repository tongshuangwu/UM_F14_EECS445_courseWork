
% Part A:
TOTAL = 5;
for i=1:TOTAL
  subplot(TOTAL, 7, (i-1)*7+1); imshow(reshape(digits_test(i,:,:), 28, 28));
  [idx, class]=q3_knn(digits_train, labels_train, digits_test, i, 8);
  disp(sprintf('%i: %i, %i, %i, %i, %i, %i, %i, %i', i, idx(1), idx(2), idx(3), idx(4), idx(5), idx(6), idx(7), idx(8)))
  for j=1:8
    subplot(TOTAL, 9, (i-1)*9+1+j); imshow(reshape(digits_train( idx(j) ,:,:), 28, 28));
    
  end
end
% --- output:
% 1: 953, 691, 321, 211, 193, 837, 82, 543
% 2: 724, 754, 72, 16, 912, 982, 194, 80
% 3: 485, 399, 455, 639, 9, 679, 113, 311
% 4: 588, 952, 594, 962, 476, 638, 994, 920
% 5: 577, 605, 305, 27, 719, 901, 413, 355


% Part B:
correct = 0;
TOTAL = 1000;
for i=1:TOTAL
  [idx, class]=q3_knn(digits_train, labels_train, digits_test, i, 10);
  if class == labels_test(i)
    correct = correct + 1;
  end
end


accuracy = correct / TOTAL  % Accuracy: 85.70 %

%

