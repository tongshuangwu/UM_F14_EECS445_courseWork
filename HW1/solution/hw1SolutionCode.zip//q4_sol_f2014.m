function q4_sol_w2014

%%%%%%% q4_sol.m %%%%%%%
load('data/q4x.dat', 'q4x');
load('data/q4y.dat', 'q4y');

%q4x = [ones(size(q4x,1),1) q4x];


q4x = [q4x,ones(size(q4x,1),1)];
[w, ll] = log_regression(q4x,q4y);
m=size(q4x,1);

hold on
plot(q4x(q4y==0,1),q4x(q4y==0,2),'rx');
plot(q4x(q4y==1,1),q4x(q4y==1,2),'go');

x = min(q4x(:,1)):.01:max(q4x(:,1));
y = -w(3)/w(2)-w(1)/w(2)*x;
plot(x,y); 
hold off
xlabel('x_1');
ylabel('x_2');

w

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% sigmoid.m %%%%%%%%%%%%%%
function a = sigmoid(x)
a = 1./(1+exp(-x));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end


%%%%%%% log_regression.m %%%%%%%
function [w,ll] = log_regression(X,Y)
% rows of X are training samples
% rows of Y are corresponding 0/1 values
% newton raphson: w = w - inv(H)* grad;
% with H = hessian, grad = gradient
m = size(X,1);
n = size(X,2);
w = zeros(n,1);
max_iters = 100;
for i=1:max_iters
    grad = zeros(n,1);
    ll(i)=0;
    H = zeros(n,n);
    for j=1:m
        hxj = sigmoid(X(j,:)*w);
        grad = grad + X(j,:)'*(Y(j) - hxj);
        H = H - hxj*(1-hxj)*X(j,:)'*X(j,:);
        ll(i) = ll(i) + Y(j)*log(hxj) + (1-Y(j))*log(1-hxj);
    end
    w = w - inv(H)*grad;
end

end
